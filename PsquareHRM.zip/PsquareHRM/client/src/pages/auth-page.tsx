import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import { Eye, EyeOff } from "lucide-react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertUserSchema } from "@shared/schema";
import { z } from "zod";

const loginSchema = insertUserSchema.pick({ username: true, password: true });
const registerSchema = insertUserSchema.extend({
  confirmPassword: z.string().min(1, "Confirm password is required"),
}).refine((data) => data.password === data.confirmPassword, {
  message: "Passwords don't match",
  path: ["confirmPassword"],
});

type LoginForm = z.infer<typeof loginSchema>;
type RegisterForm = z.infer<typeof registerSchema>;

export default function AuthPage() {
  const [, navigate] = useLocation();
  const { user, loginMutation, registerMutation } = useAuth();
  const [isLogin, setIsLogin] = useState(true);
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);

  const loginForm = useForm<LoginForm>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      username: "",
      password: "",
    },
  });

  const registerForm = useForm<RegisterForm>({
    resolver: zodResolver(registerSchema),
    defaultValues: {
      username: "",
      password: "",
      confirmPassword: "",
      fullName: "",
    },
  });

  useEffect(() => {
    if (user) {
      navigate("/");
    }
  }, [user, navigate]);

  const onLogin = (data: LoginForm) => {
    loginMutation.mutate(data);
  };

  const onRegister = (data: RegisterForm) => {
    const { confirmPassword, ...registerData } = data;
    registerMutation.mutate(registerData);
  };

  if (user) {
    return null; // Prevent flash of auth page when user is logged in
  }

  return (
    <div className="min-h-screen flex">
      {/* Left Side - Carousel */}
      <div className="flex-1 bg-psquare-purple relative overflow-hidden">
        <div className="absolute inset-0 flex items-center justify-center p-12">
          <div className="text-center text-white max-w-2xl">
            {/* Company Logo Preview */}
            <div className="bg-white rounded-lg shadow-2xl p-8 mb-8 transform rotate-2 hover:rotate-0 transition-transform duration-500">
              <div className="h-64 bg-gradient-to-br from-gray-100 to-gray-200 rounded flex items-center justify-center">
                <div className="text-center">
                  <img 
                    src="/attached_assets/Capture22222_1753348740689.PNG" 
                    alt="PSQUARE COMPANY HR Dashboard" 
                    className="max-w-full max-h-full object-contain"
                  />
                </div>
              </div>
            </div>
            
            <h2 className="text-3xl font-bold mb-4">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod</h2>
            <p className="text-lg opacity-90 mb-8">tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
            
            {/* Carousel Dots */}
            <div className="flex justify-center space-x-2">
              <div className="w-3 h-3 bg-white rounded-full"></div>
              <div className="w-3 h-3 bg-white opacity-50 rounded-full"></div>
              <div className="w-3 h-3 bg-white opacity-50 rounded-full"></div>
            </div>
          </div>
        </div>
      </div>

      {/* Right Side - Auth Forms */}
      <div className="flex-1 bg-white flex items-center justify-center p-12">
        <div className="w-full max-w-md">
          <div className="mb-8">
            <h3 className="text-2xl font-semibold text-psquare-dark mb-2">Welcome to Dashboard</h3>
          </div>

          {isLogin ? (
            <Card>
              <CardContent className="pt-6">
                <form onSubmit={loginForm.handleSubmit(onLogin)} className="space-y-6">
                  <div>
                    <Label htmlFor="username" className="text-psquare-dark">Email Address*</Label>
                    <Input
                      id="username"
                      type="email"
                      placeholder="Email Address"
                      {...loginForm.register("username")}
                      className="mt-2"
                    />
                    {loginForm.formState.errors.username && (
                      <p className="text-red-500 text-sm mt-1">{loginForm.formState.errors.username.message}</p>
                    )}
                  </div>

                  <div>
                    <Label htmlFor="password" className="text-psquare-dark">Password*</Label>
                    <div className="relative mt-2">
                      <Input
                        id="password"
                        type={showPassword ? "text" : "password"}
                        placeholder="Password"
                        {...loginForm.register("password")}
                        className="pr-12"
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
                      >
                        {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                      </button>
                    </div>
                    {loginForm.formState.errors.password && (
                      <p className="text-red-500 text-sm mt-1">{loginForm.formState.errors.password.message}</p>
                    )}
                  </div>

                  <div className="text-right">
                    <button type="button" className="text-sm text-psquare-purple hover:underline">
                      Forgot password?
                    </button>
                  </div>

                  <Button
                    type="submit"
                    className="w-full bg-psquare-purple hover:bg-purple-700"
                    disabled={loginMutation.isPending}
                  >
                    {loginMutation.isPending ? "Logging in..." : "Login"}
                  </Button>

                  <div className="text-center">
                    <span className="text-sm text-gray-600">Don't have an account? </span>
                    <button
                      type="button"
                      onClick={() => setIsLogin(false)}
                      className="text-sm text-psquare-purple hover:underline font-medium"
                    >
                      Register
                    </button>
                  </div>
                </form>
              </CardContent>
            </Card>
          ) : (
            <Card>
              <CardContent className="pt-6">
                <form onSubmit={registerForm.handleSubmit(onRegister)} className="space-y-6">
                  <div>
                    <Label htmlFor="fullName" className="text-psquare-dark">Full name*</Label>
                    <Input
                      id="fullName"
                      type="text"
                      placeholder="Full Name"
                      {...registerForm.register("fullName")}
                      className="mt-2"
                    />
                    {registerForm.formState.errors.fullName && (
                      <p className="text-red-500 text-sm mt-1">{registerForm.formState.errors.fullName.message}</p>
                    )}
                  </div>

                  <div>
                    <Label htmlFor="regUsername" className="text-psquare-dark">Email Address*</Label>
                    <Input
                      id="regUsername"
                      type="email"
                      placeholder="Email Address"
                      {...registerForm.register("username")}
                      className="mt-2"
                    />
                    {registerForm.formState.errors.username && (
                      <p className="text-red-500 text-sm mt-1">{registerForm.formState.errors.username.message}</p>
                    )}
                  </div>

                  <div>
                    <Label htmlFor="regPassword" className="text-psquare-dark">Password*</Label>
                    <div className="relative mt-2">
                      <Input
                        id="regPassword"
                        type={showPassword ? "text" : "password"}
                        placeholder="Password"
                        {...registerForm.register("password")}
                        className="pr-12"
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
                      >
                        {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                      </button>
                    </div>
                    {registerForm.formState.errors.password && (
                      <p className="text-red-500 text-sm mt-1">{registerForm.formState.errors.password.message}</p>
                    )}
                  </div>

                  <div>
                    <Label htmlFor="confirmPassword" className="text-psquare-dark">Confirm Password*</Label>
                    <div className="relative mt-2">
                      <Input
                        id="confirmPassword"
                        type={showConfirmPassword ? "text" : "password"}
                        placeholder="Confirm Password"
                        {...registerForm.register("confirmPassword")}
                        className="pr-12"
                      />
                      <button
                        type="button"
                        onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                        className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
                      >
                        {showConfirmPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                      </button>
                    </div>
                    {registerForm.formState.errors.confirmPassword && (
                      <p className="text-red-500 text-sm mt-1">{registerForm.formState.errors.confirmPassword.message}</p>
                    )}
                  </div>

                  <Button
                    type="submit"
                    className="w-full bg-psquare-purple hover:bg-purple-700"
                    disabled={registerMutation.isPending}
                  >
                    {registerMutation.isPending ? "Registering..." : "Register"}
                  </Button>

                  <div className="text-center">
                    <span className="text-sm text-gray-600">Already have an account? </span>
                    <button
                      type="button"
                      onClick={() => setIsLogin(true)}
                      className="text-sm text-psquare-purple hover:underline font-medium"
                    >
                      Login
                    </button>
                  </div>
                </form>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
