import { useState } from "react";
import Sidebar from "@/components/sidebar";
import CandidatesModule from "@/components/candidates-module";
import EmployeesModule from "@/components/employees-module";
import AttendanceModule from "@/components/attendance-module";
import LeavesModule from "@/components/leaves-module";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Bell, Mail, ChevronDown, LogOut, User } from "lucide-react";

export default function Dashboard() {
  const [activeModule, setActiveModule] = useState("candidates");
  const { user, logoutMutation } = useAuth();

  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map(word => word.charAt(0))
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  const moduleNames = {
    candidates: "Candidates",
    employees: "Employees",
    attendance: "Attendance",
    leaves: "Leaves",
  };

  const renderModule = () => {
    switch (activeModule) {
      case "candidates":
        return <CandidatesModule />;
      case "employees":
        return <EmployeesModule />;
      case "attendance":
        return <AttendanceModule />;
      case "leaves":
        return <LeavesModule />;
      default:
        return <CandidatesModule />;
    }
  };

  return (
    <div className="min-h-screen bg-psquare-light">
      <Sidebar activeModule={activeModule} onModuleChange={setActiveModule} />
      
      {/* Main Content */}
      <div className="ml-64 min-h-screen">
        {/* Header */}
        <header className="bg-white shadow-sm border-b border-gray-200 px-6 py-4">
          <div className="flex items-center justify-between">
            <h1 className="text-2xl font-semibold text-psquare-dark">
              {moduleNames[activeModule as keyof typeof moduleNames]}
            </h1>
            
            <div className="flex items-center space-x-4">
              {/* Notifications */}
              <button className="relative p-2 text-gray-400 hover:text-gray-600">
                <Mail className="h-5 w-5" />
              </button>
              <button className="relative p-2 text-gray-400 hover:text-gray-600">
                <Bell className="h-5 w-5" />
                <span className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full"></span>
              </button>

              {/* User Menu */}
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="flex items-center space-x-2 h-auto p-1">
                    <Avatar className="h-8 w-8">
                      <AvatarFallback className="bg-psquare-purple text-white text-xs">
                        {user ? getInitials(user.fullName || user.username) : 'U'}
                      </AvatarFallback>
                    </Avatar>
                    <ChevronDown className="h-4 w-4 text-gray-400" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56">
                  <DropdownMenuItem className="flex items-center space-x-2">
                    <User className="h-4 w-4" />
                    <span>Profile</span>
                  </DropdownMenuItem>
                  <DropdownMenuItem 
                    className="flex items-center space-x-2 text-red-600"
                    onClick={handleLogout}
                  >
                    <LogOut className="h-4 w-4" />
                    <span>Logout</span>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        </header>

        {/* Page Content */}
        <main className="p-6">
          {renderModule()}
        </main>
      </div>
    </div>
  );
}
