import { useAuth } from "@/hooks/use-auth";
import { Search, Users, UserCheck, Calendar, CalendarX, LogOut, BarChart3 } from "lucide-react";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";

interface SidebarProps {
  activeModule: string;
  onModuleChange: (module: string) => void;
}

export default function Sidebar({ activeModule, onModuleChange }: SidebarProps) {
  const { logoutMutation } = useAuth();

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  const navItems = [
    {
      section: "Recruitment",
      items: [
        { key: "candidates", label: "Candidates", icon: Users },
      ],
    },
    {
      section: "Organization",
      items: [
        { key: "employees", label: "Employees", icon: UserCheck },
        { key: "attendance", label: "Attendance", icon: Calendar },
        { key: "leaves", label: "Leaves", icon: CalendarX },
      ],
    },
  ];

  return (
    <div className="fixed left-0 top-0 h-full w-64 bg-white shadow-lg z-40">
      <div className="p-6">
        {/* Logo */}
        <div className="flex items-center space-x-3 mb-8">
          <div className="w-12 h-8 bg-white rounded-lg overflow-hidden flex items-center justify-center p-1">
            <img 
              src="/attached_assets/Capture22222_1753348740689.PNG" 
              alt="PSQUARE COMPANY" 
              className="w-full h-full object-contain"
            />
          </div>
        </div>

        {/* Search */}
        <div className="relative mb-8">
          <Input
            placeholder="Search"
            className="pl-10 pr-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-psquare-purple focus:border-transparent"
          />
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
        </div>

        {/* Navigation */}
        <nav className="space-y-2">
          {navItems.map((section) => (
            <div key={section.section}>
              <div className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-4">
                {section.section}
              </div>
              
              {section.items.map((item) => {
                const Icon = item.icon;
                const isActive = activeModule === item.key;
                
                return (
                  <button
                    key={item.key}
                    onClick={() => onModuleChange(item.key)}
                    className={cn(
                      "flex items-center space-x-3 px-3 py-2 rounded-lg w-full text-left transition-colors",
                      isActive
                        ? "text-psquare-purple bg-purple-50"
                        : "text-gray-600 hover:bg-gray-50"
                    )}
                  >
                    <Icon className="h-5 w-5" />
                    <span>{item.label}</span>
                  </button>
                );
              })}
              
              {section.section === "Organization" && (
                <div className="mt-6" />
              )}
            </div>
          ))}

          <div className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-4 mt-6">
            Others
          </div>
          
          <button
            onClick={handleLogout}
            disabled={logoutMutation.isPending}
            className="flex items-center space-x-3 px-3 py-2 rounded-lg text-gray-600 hover:bg-gray-50 w-full text-left transition-colors"
          >
            <LogOut className="h-5 w-5" />
            <span>{logoutMutation.isPending ? "Logging out..." : "Logout"}</span>
          </button>
        </nav>
      </div>
    </div>
  );
}
