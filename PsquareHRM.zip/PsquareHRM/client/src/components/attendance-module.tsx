import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Search, MoreVertical, ChevronDown } from "lucide-react";
import { Attendance, Employee } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

type AttendanceWithEmployee = Attendance & { employee: Employee };

export default function AttendanceModule() {
  const [statusFilter, setStatusFilter] = useState("all");
  const [searchQuery, setSearchQuery] = useState("");
  const { toast } = useToast();

  const { data: attendanceRecords = [], isLoading } = useQuery<AttendanceWithEmployee[]>({
    queryKey: ["/api/attendance"],
  });

  const updateAttendanceMutation = useMutation({
    mutationFn: async ({ id, status }: { id: number; status: string }) => {
      const res = await apiRequest("PUT", `/api/attendance/${id}`, { status });
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/attendance"] });
      toast({
        title: "Success",
        description: "Attendance status updated successfully",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update attendance status",
        variant: "destructive",
      });
    },
  });

  const filteredAttendance = attendanceRecords.filter((record) => {
    const matchesStatus = statusFilter === "all" || record.status === statusFilter;
    const matchesSearch = searchQuery === "" || 
      record.employee.fullName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      record.employee.position.toLowerCase().includes(searchQuery.toLowerCase()) ||
      record.employee.department.toLowerCase().includes(searchQuery.toLowerCase());
    
    return matchesStatus && matchesSearch;
  });

  const handleStatusChange = (attendanceId: number, newStatus: string) => {
    updateAttendanceMutation.mutate({ id: attendanceId, status: newStatus });
  };

  const getInitials = (name: string) => {
    return name.split(' ').map(n => n[0]).join('').toUpperCase();
  };

  const getStatusSelectClass = (status: string) => {
    return status === "present" 
      ? "border-green-300 text-green-600 bg-green-50" 
      : "border-red-300 text-red-600 bg-red-50";
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-lg">Loading attendance records...</div>
      </div>
    );
  }

  return (
    <div>
      <Card>
        {/* Filters and Actions */}
        <div className="p-6 border-b border-gray-200">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-40">
                  <SelectValue placeholder="Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="present">Present</SelectItem>
                  <SelectItem value="absent">Absent</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="relative">
              <Input
                placeholder="Search"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 pr-4 py-2 w-64"
              />
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
            </div>
          </div>
        </div>

        {/* Table */}
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow className="bg-psquare-purple hover:bg-psquare-purple">
                <TableHead className="text-white font-medium">Profile</TableHead>
                <TableHead className="text-white font-medium">Employee Name</TableHead>
                <TableHead className="text-white font-medium">Position</TableHead>
                <TableHead className="text-white font-medium">Department</TableHead>
                <TableHead className="text-white font-medium">Task</TableHead>
                <TableHead className="text-white font-medium">Status</TableHead>
                <TableHead className="text-white font-medium">Action</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredAttendance.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={7} className="text-center py-8 text-gray-500">
                    No attendance records found
                  </TableCell>
                </TableRow>
              ) : (
                filteredAttendance.map((record) => (
                  <TableRow key={record.id} className="hover:bg-gray-50">
                    <TableCell>
                      <Avatar className="h-8 w-8">
                        <AvatarFallback className="bg-gray-300 text-gray-600 text-xs">
                          {getInitials(record.employee.fullName)}
                        </AvatarFallback>
                      </Avatar>
                    </TableCell>
                    <TableCell className="font-medium">{record.employee.fullName}</TableCell>
                    <TableCell>{record.employee.position}</TableCell>
                    <TableCell>{record.employee.department}</TableCell>
                    <TableCell>{record.task || "No task assigned"}</TableCell>
                    <TableCell>
                      <div className="relative">
                        <select
                          value={record.status}
                          onChange={(e) => handleStatusChange(record.id, e.target.value)}
                          disabled={updateAttendanceMutation.isPending}
                          className={`px-3 py-1 border rounded text-sm appearance-none pr-8 cursor-pointer ${getStatusSelectClass(record.status)}`}
                        >
                          <option value="present">Present</option>
                          <option value="absent">Absent</option>
                        </select>
                        <ChevronDown className={`absolute right-2 top-1/2 transform -translate-y-1/2 text-xs pointer-events-none ${
                          record.status === "present" ? "text-green-600" : "text-red-600"
                        }`} size={12} />
                      </div>
                    </TableCell>
                    <TableCell>
                      <Button variant="ghost" size="sm">
                        <MoreVertical className="h-4 w-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
