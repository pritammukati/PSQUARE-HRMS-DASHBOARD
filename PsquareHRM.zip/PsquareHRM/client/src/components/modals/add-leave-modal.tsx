import { useState } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { X, Upload, Calendar } from "lucide-react";
import { insertLeaveSchema, Employee } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { z } from "zod";

type LeaveForm = Omit<z.infer<typeof insertLeaveSchema>, 'startDate' | 'endDate'> & {
  startDate: string;
  endDate: string;
  documents?: File;
};

const leaveFormSchema = insertLeaveSchema.omit({ startDate: true, endDate: true }).extend({
  startDate: z.string().min(1, "Leave date is required"),
  endDate: z.string().min(1, "End date is required"),
});

interface AddLeaveModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function AddLeaveModal({ isOpen, onClose }: AddLeaveModalProps) {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const { toast } = useToast();

  // Get list of present employees only
  const { data: employees = [] } = useQuery<Employee[]>({
    queryKey: ["/api/employees"],
    select: (data) => data.filter(emp => emp.status === "present"),
  });

  const form = useForm<LeaveForm>({
    resolver: zodResolver(leaveFormSchema),
    defaultValues: {
      employeeId: 0,
      startDate: "",
      endDate: "",
      reason: "",
      designation: "",
      status: "pending",
    },
  });

  const createLeaveMutation = useMutation({
    mutationFn: async (data: LeaveForm) => {
      const formData = new FormData();
      
      // Append all fields
      formData.append("employeeId", data.employeeId.toString());
      formData.append("startDate", data.startDate);
      formData.append("endDate", data.endDate);
      formData.append("reason", data.reason);
      formData.append("status", data.status);
      
      if (data.designation) {
        formData.append("designation", data.designation);
      }
      
      // Append file if selected
      if (selectedFile) {
        formData.append("documents", selectedFile);
      }

      const res = await fetch("/api/leaves", {
        method: "POST",
        body: formData,
        credentials: "include",
      });

      if (!res.ok) {
        throw new Error(`${res.status}: ${await res.text()}`);
      }

      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/leaves"] });
      queryClient.invalidateQueries({ queryKey: ["/api/leaves/approved"] });
      toast({
        title: "Success",
        description: "Leave application submitted successfully",
      });
      handleClose();
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to submit leave application",
        variant: "destructive",
      });
    },
  });

  const handleClose = () => {
    form.reset();
    setSelectedFile(null);
    onClose();
  };

  const onSubmit = (data: LeaveForm) => {
    createLeaveMutation.mutate(data);
  };

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setSelectedFile(file);
    }
  };

  const selectedEmployee = employees.find(emp => emp.id === form.watch("employeeId"));

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        {/* Modal Header */}
        <DialogHeader className="bg-psquare-purple text-white px-6 py-4 -mx-6 -mt-6 rounded-t-lg">
          <div className="flex items-center justify-between">
            <DialogTitle className="text-lg font-medium">Add New Leave</DialogTitle>
            <Button
              variant="ghost"
              size="sm"
              onClick={handleClose}
              className="text-white hover:text-gray-200 hover:bg-purple-600 p-1"
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
        </DialogHeader>

        {/* Modal Body */}
        <div className="px-6 py-6">
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <Label htmlFor="employeeId" className="text-gray-700 font-medium">Employee*</Label>
                <Select
                  value={form.watch("employeeId")?.toString()}
                  onValueChange={(value) => form.setValue("employeeId", parseInt(value))}
                >
                  <SelectTrigger className="mt-2 border-psquare-purple focus:ring-psquare-purple">
                    <SelectValue placeholder="Select employee" />
                  </SelectTrigger>
                  <SelectContent>
                    {employees.map((employee) => (
                      <SelectItem key={employee.id} value={employee.id.toString()}>
                        {employee.fullName}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {form.formState.errors.employeeId && (
                  <p className="text-red-500 text-sm mt-1">{form.formState.errors.employeeId.message}</p>
                )}
                {employees.length === 0 && (
                  <p className="text-yellow-600 text-sm mt-1">No present employees available</p>
                )}
              </div>

              <div>
                <Label htmlFor="designation" className="text-gray-700 font-medium">Designation</Label>
                <Input
                  id="designation"
                  {...form.register("designation")}
                  className="mt-2 border-psquare-purple focus:ring-psquare-purple"
                  placeholder="Designation"
                  value={selectedEmployee?.position || ""}
                  readOnly
                />
              </div>

              <div>
                <Label htmlFor="startDate" className="text-gray-700 font-medium">Leave Date*</Label>
                <div className="relative mt-2">
                  <Input
                    id="startDate"
                    type="date"
                    {...form.register("startDate")}
                    className="border-psquare-purple focus:ring-psquare-purple pr-12"
                  />
                  <Calendar className="absolute right-3 top-1/2 transform -translate-y-1/2 text-psquare-purple h-4 w-4 pointer-events-none" />
                </div>
                {form.formState.errors.startDate && (
                  <p className="text-red-500 text-sm mt-1">{form.formState.errors.startDate.message}</p>
                )}
              </div>

              <div>
                <Label htmlFor="documents" className="text-gray-700 font-medium">Documents</Label>
                <div className="mt-2 border-2 border-dashed border-psquare-purple rounded-lg p-4 text-center hover:border-purple-400 transition-colors">
                  <Upload className="mx-auto h-6 w-6 text-psquare-purple mb-2" />
                  <p className="text-sm text-gray-600">
                    {selectedFile ? selectedFile.name : "Documents"}
                  </p>
                  <input
                    type="file"
                    accept=".pdf,.doc,.docx,.jpg,.jpeg,.png"
                    onChange={handleFileChange}
                    className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                  />
                </div>
              </div>
            </div>

            <div>
              <Label htmlFor="reason" className="text-gray-700 font-medium">Reason*</Label>
              <Input
                id="reason"
                {...form.register("reason")}
                className="mt-2 border-psquare-purple focus:ring-psquare-purple"
                placeholder="Reason for leave"
              />
              {form.formState.errors.reason && (
                <p className="text-red-500 text-sm mt-1">{form.formState.errors.reason.message}</p>
              )}
            </div>

            {/* Hidden field for end date - same as start date for single day leave */}
            <input
              type="hidden"
              {...form.register("endDate")}
              value={form.watch("startDate")}
            />

            <div className="flex justify-center">
              <Button
                type="submit"
                disabled={createLeaveMutation.isPending || !form.formState.isValid || employees.length === 0}
                className={`px-8 py-3 rounded-lg font-medium ${
                  form.formState.isValid && employees.length > 0
                    ? "bg-psquare-purple hover:bg-purple-700 text-white"
                    : "bg-gray-300 text-gray-500 cursor-not-allowed"
                }`}
              >
                {createLeaveMutation.isPending ? "Saving..." : "Save"}
              </Button>
            </div>
          </form>
        </div>
      </DialogContent>
    </Dialog>
  );
}
