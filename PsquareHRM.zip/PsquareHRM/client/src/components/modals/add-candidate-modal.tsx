import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { X, Upload } from "lucide-react";
import { insertCandidateSchema } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { z } from "zod";

type CandidateForm = z.infer<typeof insertCandidateSchema> & {
  resume?: File;
  declaration: boolean;
};

const candidateFormSchema = insertCandidateSchema.extend({
  declaration: z.boolean().refine(val => val === true, {
    message: "You must accept the declaration"
  })
});

interface AddCandidateModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function AddCandidateModal({ isOpen, onClose }: AddCandidateModalProps) {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const { toast } = useToast();

  const form = useForm<CandidateForm>({
    resolver: zodResolver(candidateFormSchema),
    defaultValues: {
      fullName: "",
      email: "",
      phone: "",
      position: "",
      experience: "",
      status: "active",
      declaration: false,
    },
  });

  const createCandidateMutation = useMutation({
    mutationFn: async (data: CandidateForm) => {
      const formData = new FormData();
      
      // Append all text fields
      formData.append("fullName", data.fullName);
      formData.append("email", data.email);
      formData.append("phone", data.phone);
      formData.append("position", data.position);
      formData.append("experience", data.experience);
      formData.append("status", data.status);
      
      // Append file if selected
      if (selectedFile) {
        formData.append("resume", selectedFile);
      }

      const res = await fetch("/api/candidates", {
        method: "POST",
        body: formData,
        credentials: "include",
      });

      if (!res.ok) {
        throw new Error(`${res.status}: ${await res.text()}`);
      }

      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/candidates"] });
      toast({
        title: "Success",
        description: "Candidate added successfully",
      });
      handleClose();
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to add candidate",
        variant: "destructive",
      });
    },
  });

  const handleClose = () => {
    form.reset();
    setSelectedFile(null);
    onClose();
  };

  const onSubmit = (data: CandidateForm) => {
    createCandidateMutation.mutate(data);
  };

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setSelectedFile(file);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        {/* Modal Header */}
        <DialogHeader className="bg-psquare-purple text-white px-6 py-4 -mx-6 -mt-6 rounded-t-lg">
          <div className="flex items-center justify-between">
            <DialogTitle className="text-lg font-medium">Add New Candidate</DialogTitle>
            <Button
              variant="ghost"
              size="sm"
              onClick={handleClose}
              className="text-white hover:text-gray-200 hover:bg-purple-600 p-1"
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
        </DialogHeader>

        {/* Modal Body */}
        <div className="px-6 py-6">
          <form onSubmit={form.handleSubmit(onSubmit)} className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <Label htmlFor="fullName" className="text-gray-700 font-medium">Full Name*</Label>
              <Input
                id="fullName"
                {...form.register("fullName")}
                className="mt-2"
                placeholder="Enter full name"
              />
              {form.formState.errors.fullName && (
                <p className="text-red-500 text-sm mt-1">{form.formState.errors.fullName.message}</p>
              )}
            </div>

            <div>
              <Label htmlFor="email" className="text-gray-700 font-medium">Email Address*</Label>
              <Input
                id="email"
                type="email"
                {...form.register("email")}
                className="mt-2"
                placeholder="Enter email address"
              />
              {form.formState.errors.email && (
                <p className="text-red-500 text-sm mt-1">{form.formState.errors.email.message}</p>
              )}
            </div>

            <div>
              <Label htmlFor="phone" className="text-gray-700 font-medium">Phone Number*</Label>
              <Input
                id="phone"
                type="tel"
                {...form.register("phone")}
                className="mt-2"
                placeholder="Enter phone number"
              />
              {form.formState.errors.phone && (
                <p className="text-red-500 text-sm mt-1">{form.formState.errors.phone.message}</p>
              )}
            </div>

            <div>
              <Label htmlFor="position" className="text-gray-700 font-medium">Position*</Label>
              <Input
                id="position"
                {...form.register("position")}
                className="mt-2"
                placeholder="Enter position"
              />
              {form.formState.errors.position && (
                <p className="text-red-500 text-sm mt-1">{form.formState.errors.position.message}</p>
              )}
            </div>

            <div>
              <Label htmlFor="experience" className="text-gray-700 font-medium">Experience*</Label>
              <Input
                id="experience"
                {...form.register("experience")}
                className="mt-2"
                placeholder="Enter experience (e.g., 3 years)"
              />
              {form.formState.errors.experience && (
                <p className="text-red-500 text-sm mt-1">{form.formState.errors.experience.message}</p>
              )}
            </div>

            <div>
              <Label htmlFor="resume" className="text-gray-700 font-medium">Resume*</Label>
              <div className="mt-2 border-2 border-dashed border-gray-300 rounded-lg p-4 text-center hover:border-gray-400 transition-colors">
                <Upload className="mx-auto h-8 w-8 text-gray-400 mb-2" />
                <p className="text-sm text-gray-600 mb-2">
                  {selectedFile ? selectedFile.name : "Click to upload or drag and drop"}
                </p>
                <p className="text-xs text-gray-500">PDF, DOC, DOCX files only</p>
                <input
                  type="file"
                  accept=".pdf,.doc,.docx"
                  onChange={handleFileChange}
                  className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                />
              </div>
            </div>

            <div className="md:col-span-2">
              <div className="flex items-start space-x-2">
                <Checkbox
                  id="declaration"
                  checked={form.watch("declaration")}
                  onCheckedChange={(checked) => form.setValue("declaration", !!checked)}
                />
                <Label htmlFor="declaration" className="text-sm text-gray-600 leading-relaxed">
                  I hereby declare that the above information is true to the best of my knowledge and belief
                </Label>
              </div>
              {form.formState.errors.declaration && (
                <p className="text-red-500 text-sm mt-1">{form.formState.errors.declaration.message}</p>
              )}
            </div>

            <div className="md:col-span-2 flex justify-center">
              <Button
                type="submit"
                disabled={createCandidateMutation.isPending || !form.formState.isValid}
                className={`px-8 py-3 rounded-lg font-medium ${
                  form.formState.isValid && form.watch("declaration")
                    ? "bg-psquare-purple hover:bg-purple-700 text-white"
                    : "bg-gray-300 text-gray-500 cursor-not-allowed"
                }`}
              >
                {createCandidateMutation.isPending ? "Saving..." : "Save"}
              </Button>
            </div>
          </form>
        </div>
      </DialogContent>
    </Dialog>
  );
}
