import { useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { X, Calendar } from "lucide-react";
import { insertEmployeeSchema } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { z } from "zod";

type EmployeeForm = Omit<z.infer<typeof insertEmployeeSchema>, 'dateOfJoining'> & {
  dateOfJoining: string;
};

const employeeFormSchema = insertEmployeeSchema.omit({ dateOfJoining: true }).extend({
  dateOfJoining: z.string().min(1, "Date of joining is required")
});

interface AddEmployeeModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function AddEmployeeModal({ isOpen, onClose }: AddEmployeeModalProps) {
  const { toast } = useToast();

  const form = useForm<EmployeeForm>({
    resolver: zodResolver(employeeFormSchema),
    defaultValues: {
      fullName: "",
      email: "",
      phone: "",
      position: "",
      department: "",
      dateOfJoining: "",
      status: "present",
    },
  });

  const createEmployeeMutation = useMutation({
    mutationFn: async (data: EmployeeForm) => {
      // Convert date format from MM/DD/YY to proper date
      const [month, day, year] = data.dateOfJoining.split('/');
      const fullYear = parseInt(year) < 50 ? 2000 + parseInt(year) : 1900 + parseInt(year);
      const isoDate = new Date(fullYear, parseInt(month) - 1, parseInt(day)).toISOString();
      
      const createData = {
        ...data,
        dateOfJoining: isoDate,
      };
      
      const res = await apiRequest("POST", "/api/employees", createData);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/employees"] });
      toast({
        title: "Success",
        description: "Employee added successfully",
      });
      handleClose();
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to add employee",
        variant: "destructive",
      });
    },
  });

  const handleClose = () => {
    form.reset();
    onClose();
  };

  const onSubmit = (data: EmployeeForm) => {
    createEmployeeMutation.mutate(data);
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        {/* Modal Header */}
        <DialogHeader className="bg-psquare-purple text-white px-6 py-4 -mx-6 -mt-6 rounded-t-lg">
          <div className="flex items-center justify-between">
            <DialogTitle className="text-lg font-medium">Add New Employee</DialogTitle>
            <Button
              variant="ghost"
              size="sm"
              onClick={handleClose}
              className="text-white hover:text-gray-200 hover:bg-purple-600 p-1"
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
        </DialogHeader>

        {/* Modal Body */}
        <div className="px-6 py-6">
          <form onSubmit={form.handleSubmit(onSubmit)} className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <Label htmlFor="fullName" className="text-psquare-purple font-medium">Full Name*</Label>
              <Input
                id="fullName"
                {...form.register("fullName")}
                className="mt-2 border-psquare-purple focus:ring-psquare-purple"
                placeholder="Enter full name"
              />
              {form.formState.errors.fullName && (
                <p className="text-red-500 text-sm mt-1">{form.formState.errors.fullName.message}</p>
              )}
            </div>

            <div>
              <Label htmlFor="email" className="text-psquare-purple font-medium">Email Address*</Label>
              <Input
                id="email"
                type="email"
                {...form.register("email")}
                className="mt-2 border-psquare-purple focus:ring-psquare-purple"
                placeholder="Enter email address"
              />
              {form.formState.errors.email && (
                <p className="text-red-500 text-sm mt-1">{form.formState.errors.email.message}</p>
              )}
            </div>

            <div>
              <Label htmlFor="phone" className="text-psquare-purple font-medium">Phone Number*</Label>
              <Input
                id="phone"
                type="tel"
                {...form.register("phone")}
                className="mt-2 border-psquare-purple focus:ring-psquare-purple"
                placeholder="Enter phone number"
              />
              {form.formState.errors.phone && (
                <p className="text-red-500 text-sm mt-1">{form.formState.errors.phone.message}</p>
              )}
            </div>

            <div>
              <Label htmlFor="department" className="text-psquare-purple font-medium">Department*</Label>
              <Input
                id="department"
                {...form.register("department")}
                className="mt-2 border-psquare-purple focus:ring-psquare-purple"
                placeholder="Enter department"
              />
              {form.formState.errors.department && (
                <p className="text-red-500 text-sm mt-1">{form.formState.errors.department.message}</p>
              )}
            </div>

            <div>
              <Label htmlFor="position" className="text-psquare-purple font-medium">Position*</Label>
              <Select
                value={form.watch("position")}
                onValueChange={(value) => form.setValue("position", value)}
              >
                <SelectTrigger className="mt-2 border-psquare-purple focus:ring-psquare-purple">
                  <SelectValue placeholder="Select position" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Intern">Intern</SelectItem>
                  <SelectItem value="Junior">Junior</SelectItem>
                  <SelectItem value="Senior">Senior</SelectItem>
                  <SelectItem value="Lead">Lead</SelectItem>
                  <SelectItem value="Manager">Manager</SelectItem>
                </SelectContent>
              </Select>
              {form.formState.errors.position && (
                <p className="text-red-500 text-sm mt-1">{form.formState.errors.position.message}</p>
              )}
            </div>

            <div>
              <Label htmlFor="dateOfJoining" className="text-psquare-purple font-medium">Date of Joining*</Label>
              <div className="relative mt-2">
                <Input
                  id="dateOfJoining"
                  {...form.register("dateOfJoining")}
                  className="border-psquare-purple focus:ring-psquare-purple pr-12"
                  placeholder="MM/DD/YY"
                />
                <Calendar className="absolute right-3 top-1/2 transform -translate-y-1/2 text-psquare-purple h-4 w-4" />
              </div>
              {form.formState.errors.dateOfJoining && (
                <p className="text-red-500 text-sm mt-1">{form.formState.errors.dateOfJoining.message}</p>
              )}
            </div>

            <div className="md:col-span-2 flex justify-center">
              <Button
                type="submit"
                disabled={createEmployeeMutation.isPending}
                className="bg-psquare-purple hover:bg-purple-700 text-white px-8 py-3 rounded-lg font-medium"
              >
                {createEmployeeMutation.isPending ? "Adding..." : "Add Employee"}
              </Button>
            </div>
          </form>
        </div>
      </DialogContent>
    </Dialog>
  );
}