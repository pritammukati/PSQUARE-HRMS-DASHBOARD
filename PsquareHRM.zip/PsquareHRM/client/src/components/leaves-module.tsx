import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Search, ChevronLeft, ChevronRight } from "lucide-react";
import { Leave, Employee } from "@shared/schema";
import AddLeaveModal from "@/components/modals/add-leave-modal";

type LeaveWithEmployee = Leave & { employee: Employee };

export default function LeavesModule() {
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [statusFilter, setStatusFilter] = useState("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [currentMonth, setCurrentMonth] = useState(new Date());

  const { data: leaves = [], isLoading } = useQuery<LeaveWithEmployee[]>({
    queryKey: ["/api/leaves"],
  });

  const { data: approvedLeaves = [] } = useQuery<LeaveWithEmployee[]>({
    queryKey: ["/api/leaves/approved"],
  });

  const filteredLeaves = leaves.filter((leave) => {
    const matchesStatus = statusFilter === "all" || leave.status === statusFilter;
    const matchesSearch = searchQuery === "" || 
      leave.employee.fullName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      leave.reason.toLowerCase().includes(searchQuery.toLowerCase());
    
    return matchesStatus && matchesSearch;
  });

  const getInitials = (name: string) => {
    return name.split(' ').map(n => n[0]).join('').toUpperCase();
  };

  const formatDate = (dateString: string | Date) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      month: '2-digit',
      day: '2-digit',
      year: '2-digit'
    });
  };

  const getStatusBadge = (status: string) => {
    const colors = {
      pending: "bg-yellow-100 text-yellow-800",
      approved: "bg-green-100 text-green-800",
      rejected: "bg-red-100 text-red-800",
    };
    return colors[status as keyof typeof colors] || "bg-gray-100 text-gray-800";
  };

  // Calendar logic
  const getDaysInMonth = (date: Date) => {
    const year = date.getFullYear();
    const month = date.getMonth();
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    const daysInMonth = lastDay.getDate();
    const startingDayOfWeek = firstDay.getDay();
    
    const days = [];
    
    // Add empty cells for days before the first day of month
    for (let i = 0; i < startingDayOfWeek; i++) {
      days.push(null);
    }
    
    // Add days of the month
    for (let i = 1; i <= daysInMonth; i++) {
      days.push(i);
    }
    
    return days;
  };

  const isLeaveDay = (day: number) => {
    if (!day) return false;
    const checkDate = new Date(currentMonth.getFullYear(), currentMonth.getMonth(), day);
    return approvedLeaves.some(leave => {
      const startDate = new Date(leave.startDate);
      const endDate = new Date(leave.endDate);
      return checkDate >= startDate && checkDate <= endDate;
    });
  };

  const navigateMonth = (direction: 'prev' | 'next') => {
    setCurrentMonth(prev => {
      const newDate = new Date(prev);
      if (direction === 'prev') {
        newDate.setMonth(prev.getMonth() - 1);
      } else {
        newDate.setMonth(prev.getMonth() + 1);
      }
      return newDate;
    });
  };

  const monthNames = [
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"
  ];

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-lg">Loading leaves...</div>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      {/* Applied Leaves Table */}
      <div className="lg:col-span-2">
        <Card>
          {/* Header */}
          <div className="p-6 border-b border-gray-200">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger className="w-40">
                    <SelectValue placeholder="Status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Status</SelectItem>
                    <SelectItem value="pending">Pending</SelectItem>
                    <SelectItem value="approved">Approved</SelectItem>
                    <SelectItem value="rejected">Rejected</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="flex items-center space-x-4">
                <div className="relative">
                  <Input
                    placeholder="Search"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10 pr-4 py-2 w-64"
                  />
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                </div>
                <Button
                  onClick={() => setIsAddModalOpen(true)}
                  className="bg-psquare-purple hover:bg-purple-700"
                >
                  Add Leave
                </Button>
              </div>
            </div>
          </div>

          {/* Applied Leaves Header */}
          <CardHeader className="bg-psquare-purple text-white py-3">
            <CardTitle className="text-base font-medium">Applied Leaves</CardTitle>
          </CardHeader>

          {/* Table Header */}
          <div className="bg-psquare-purple text-white">
            <div className="grid grid-cols-7 gap-4 px-6 py-3 text-sm font-medium">
              <div>Profile</div>
              <div>Name</div>
              <div>Date</div>
              <div>Reason</div>
              <div>Status</div>
              <div>Docs</div>
              <div>Action</div>
            </div>
          </div>

          {/* Table Content */}
          <CardContent className="p-0">
            {filteredLeaves.length === 0 ? (
              <div className="p-12 text-center">
                <div className="bg-psquare-purple text-white p-6 rounded-lg inline-block">
                  <p className="text-lg font-medium">ONLY PRESENT EMPLOYEES CAN TAKE LEAVE</p>
                </div>
              </div>
            ) : (
              <div className="divide-y divide-gray-200">
                {filteredLeaves.map((leave) => (
                  <div key={leave.id} className="grid grid-cols-7 gap-4 px-6 py-4 hover:bg-gray-50">
                    <div>
                      <Avatar className="h-8 w-8">
                        <AvatarFallback className="bg-gray-300 text-gray-600 text-xs">
                          {getInitials(leave.employee.fullName)}
                        </AvatarFallback>
                      </Avatar>
                    </div>
                    <div className="font-medium">{leave.employee.fullName}</div>
                    <div>{formatDate(leave.startDate)}</div>
                    <div>{leave.reason}</div>
                    <div>
                      <span className={`px-2 py-1 text-xs rounded-full ${getStatusBadge(leave.status)}`}>
                        {leave.status.charAt(0).toUpperCase() + leave.status.slice(1)}
                      </span>
                    </div>
                    <div>
                      {leave.documentsUrl && (
                        <Button variant="ghost" size="sm" asChild>
                          <a href={leave.documentsUrl} download className="text-psquare-purple">
                            Download
                          </a>
                        </Button>
                      )}
                    </div>
                    <div>
                      <Button variant="ghost" size="sm">
                        •••
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Leave Calendar */}
      <div>
        <Card>
          {/* Calendar Header */}
          <CardHeader className="bg-psquare-purple text-white">
            <CardTitle className="text-base font-medium">Leave Calendar</CardTitle>
          </CardHeader>

          {/* Calendar Navigation */}
          <div className="p-4 border-b border-gray-200">
            <div className="flex items-center justify-between">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => navigateMonth('prev')}
                className="text-gray-400 hover:text-gray-600 p-1"
              >
                <ChevronLeft className="h-4 w-4" />
              </Button>
              <h4 className="font-medium text-gray-900">
                {monthNames[currentMonth.getMonth()]}, {currentMonth.getFullYear()}
              </h4>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => navigateMonth('next')}
                className="text-gray-400 hover:text-gray-600 p-1"
              >
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          </div>

          {/* Calendar Grid */}
          <CardContent className="p-4">
            {/* Days Header */}
            <div className="grid grid-cols-7 gap-1 mb-2">
              {[
                { label: 'S', key: 'sun' }, 
                { label: 'M', key: 'mon' }, 
                { label: 'T', key: 'tue' }, 
                { label: 'W', key: 'wed' }, 
                { label: 'T', key: 'thu' }, 
                { label: 'F', key: 'fri' }, 
                { label: 'S', key: 'sat' }
              ].map((day) => (
                <div key={day.key} className="text-center text-xs font-medium text-gray-500 py-1">
                  {day.label}
                </div>
              ))}
            </div>

            {/* Calendar Days */}
            <div className="grid grid-cols-7 gap-1">
              {getDaysInMonth(currentMonth).map((day, index) => (
                <div
                  key={`day-${index}-${day || 'empty'}`}
                  className={`text-center py-2 text-sm cursor-pointer rounded ${
                    day 
                      ? isLeaveDay(day)
                        ? "bg-psquare-purple text-white"
                        : "text-gray-900 hover:bg-gray-50"
                      : ""
                  }`}
                >
                  {day}
                </div>
              ))}
            </div>
          </CardContent>

          {/* Approved Leaves Section */}
          <div className="border-t border-gray-200 p-4">
            <h5 className="text-sm font-medium text-psquare-purple mb-2">Approved Leaves</h5>
            <div className="text-sm text-gray-600">
              {approvedLeaves.length === 0 
                ? "No approved leaves to display"
                : `${approvedLeaves.length} approved leave(s) this month`
              }
            </div>
          </div>
        </Card>
      </div>

      <AddLeaveModal 
        isOpen={isAddModalOpen} 
        onClose={() => setIsAddModalOpen(false)} 
      />
    </div>
  );
}
